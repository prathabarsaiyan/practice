package main.pratha.splitExpenses.model;

public class EqualSplit extends Split {
    public EqualSplit(User user) {
        super(user);
    }
}