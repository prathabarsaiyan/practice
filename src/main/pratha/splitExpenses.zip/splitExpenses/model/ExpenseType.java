package main.pratha.splitExpenses.model;

public enum ExpenseType {
    EQUAL, EXACT;
}
